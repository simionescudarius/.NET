﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LibraryApplication.Models
{
    public class LoanModel{
        public int bookId { set; get; }
        public string readerEmail { set; get; }
    }
}
